//
//  ViewController.m
//  ffmpegS
//
//  Created by 软件开发部2 on 2018/4/10.
//  Copyright © 2018年 软件开发部2. All rights reserved.
//

#import "ViewController.h"
#include <libavformat/avformat.h>
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    av_register_all();
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
